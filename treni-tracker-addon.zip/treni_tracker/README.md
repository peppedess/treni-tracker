# Treni Tracker

Monitora treni italiani (Trenitalia/RFI, e di riflesso buona parte
del TPL ferroviario su rete RFI) e ricevi notifiche push fermata per
fermata: ritardo, anticipo, prossima fermata, soppressione, arrivo a
destinazione.

## Limiti noti

- **Italo**: nessuna API pubblica nota. Non tracciabile.
- **Trenord su rete non-RFI**: dati spesso assenti o incompleti.
- I dati vengono dall'API non ufficiale di ViaggiaTreno: può
  cambiare o interrompersi senza preavviso.

## Configurazione

Dalla scheda "Configurazione" di questo add-on puoi impostare:

- **vapid_contact_email**: un indirizzo email di contatto, richiesto
  dal protocollo Web Push (non viene mostrato a nessuno, è solo un
  riferimento tecnico nelle richieste push).
- **intervallo_polling_secondi**: ogni quanti secondi controllare lo
  stato dei treni monitorati (default 75, minimo 20, massimo 600).
- **soglia_variazione_ritardo**: di quanti minuti deve variare il
  ritardo prima di mandare una notifica (default 2, evita di essere
  tempestati a ogni piccola oscillazione).

## Come usarlo

1. Avvia l'add-on dalla scheda "Info"
2. Apri l'interfaccia web (pulsante "Apri interfaccia web", oppure
   dal pannello laterale di Home Assistant se hai attivato l'icona)
3. **Per le notifiche push serve un accesso HTTPS diretto** (vedi
   sezione successiva): l'Ingress di Home Assistant da solo non è
   sufficiente per registrare le notifiche in modo stabile
4. Inserisci il numero del treno, scegli la corsa giusta se il numero
   è ambiguo, attiva le notifiche

## Accesso HTTPS via Tailscale (necessario per le notifiche push)

Le notifiche push richiedono un'origine HTTPS stabile. L'Ingress di
Home Assistant non garantisce questo in modo affidabile per i service
worker dei browser. Usa invece Tailscale Serve puntando alla porta
diretta dell'add-on (8000, esposta sull'host):

```bash
tailscale serve --bg https / http://localhost:8000
```

Esegui questo comando dalla shell del sistema host (non dal container
dell'add-on) — usa l'add-on "Terminal & SSH" per accedervi.

Apri poi `https://nome-del-tuo-nuc.tuotailnet.ts.net` dal telefono
(con Tailscale attivo anche lì) per usare l'app con le notifiche
funzionanti.

## Dati persistenti

Il database SQLite e le chiavi VAPID sono salvati nella cartella dati
dell'add-on, che sopravvive ad aggiornamenti e riavvii. Non vengono
toccati da un aggiornamento dell'add-on stesso.
