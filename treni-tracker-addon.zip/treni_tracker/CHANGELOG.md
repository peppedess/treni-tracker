# Changelog

## 1.0.0

- Prima versione: monitoraggio treni via ViaggiaTreno, notifiche push
  Web Push (VAPID), interfaccia PWA con disambiguazione numero treno.
