"""
Loop in background che controlla periodicamente lo stato dei treni
monitorati e decide quando vale la pena notificare l'utente.

Regola di notifica: notifichiamo quando cambia la fermata raggiunta
(il treno è avanzato) oppure quando il ritardo varia di almeno la
soglia configurata rispetto all'ultima notifica. Questo evita di
tempestare l'utente a ogni polling se nulla di rilevante è cambiato.

Intervallo e soglia sono configurabili dalla scheda "Configurazione"
dell'add-on in Home Assistant (vedi config.py).
"""

import asyncio
import logging

from . import storage, viaggiatreno, push, config

logger = logging.getLogger("scheduler")


async def _controlla_treno(treno: dict, soglia_variazione_ritardo: int):
    treno_id = treno["id"]
    numero = treno["numero_treno"]

    try:
        stato = await viaggiatreno.andamento_treno(
            treno["stazione_partenza_cod"], numero, treno["timestamp_ms"]
        )
    except viaggiatreno.TrainNoDataError as e:
        logger.info(f"Treno {numero}: dati non disponibili ({e})")
        return
    except Exception as e:
        logger.warning(f"Treno {numero}: errore durante il controllo: {e}")
        return

    if stato["soppresso"]:
        push.invia_notifica_a_tutti(
            f"Treno {numero} soppresso",
            f"Il treno {numero} ({treno['stazione_partenza_nome']} → "
            f"{treno['stazione_destinazione_nome']}) è stato soppresso.",
            {"treno_id": treno_id},
        )
        storage.rimuovi_treno(treno_id)
        return

    ritardo_attuale = stato["ritardo_minuti"] or 0
    ultima_stazione_rilevata = stato["ultima_stazione_rilevata"]
    ritardo_precedente = treno["ultimo_ritardo"]
    stazione_precedente = treno["ultima_stazione_notificata"]

    cambio_stazione = (
        ultima_stazione_rilevata
        and ultima_stazione_rilevata != stazione_precedente
    )
    variazione_ritardo_significativa = (
        ritardo_precedente is None
        or abs(ritardo_attuale - ritardo_precedente) >= soglia_variazione_ritardo
    )

    if cambio_stazione or variazione_ritardo_significativa:
        corpo = _costruisci_messaggio(stato, ultima_stazione_rilevata, ritardo_attuale)
        push.invia_notifica_a_tutti(f"Treno {numero}", corpo, {"treno_id": treno_id})
        storage.aggiorna_stato_treno(treno_id, ritardo_attuale, ultima_stazione_rilevata, stato)

    fermate = stato["fermate"]
    if fermate:
        ultima_fermata = fermate[-1]
        if ultima_fermata["passata"] and ultima_fermata["stazione"] == stato["stazione_destinazione"]:
            push.invia_notifica_a_tutti(
                f"Treno {numero} arrivato",
                f"Il treno {numero} è arrivato a {stato['stazione_destinazione']}.",
                {"treno_id": treno_id},
            )
            storage.rimuovi_treno(treno_id)


def _costruisci_messaggio(stato: dict, stazione: str, ritardo: int) -> str:
    if ritardo > 0:
        riga_ritardo = f"in ritardo di {ritardo} min"
    elif ritardo < 0:
        riga_ritardo = f"in anticipo di {abs(ritardo)} min"
    else:
        riga_ritardo = "in orario"

    if stazione:
        return f"A {stazione}, {riga_ritardo}."
    return f"Aggiornamento: {riga_ritardo}."


async def loop_scheduler():
    """Task in background avviato all'avvio dell'app (vedi main.py)."""
    intervallo = config.get_intervallo_polling_secondi()
    soglia = config.get_soglia_variazione_ritardo()
    logger.info(f"Scheduler avviato (intervallo={intervallo}s, soglia_ritardo={soglia}min)")

    while True:
        try:
            treni = storage.lista_treni_attivi()
            for treno in treni:
                await _controlla_treno(treno, soglia)
        except Exception as e:
            logger.error(f"Errore nel ciclo dello scheduler: {e}")
        await asyncio.sleep(intervallo)
