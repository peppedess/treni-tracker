"""
Invio di notifiche Web Push standard (protocollo VAPID).

Le chiavi VAPID si generano una volta sola e si tengono fisse: se
cambiano, tutte le subscription esistenti diventano invalide e ogni
utente deve dare di nuovo il permesso.
"""

import json
from pathlib import Path

from py_vapid import Vapid01
from pywebpush import webpush, WebPushException

from . import storage, config

VAPID_DIR = Path("/data/vapid")
VAPID_PRIVATE_PEM = VAPID_DIR / "private_key.pem"


def init_vapid_keys() -> dict:
    """Genera la coppia di chiavi VAPID se non esiste già. Ritorna la chiave pubblica."""
    VAPID_DIR.mkdir(parents=True, exist_ok=True)
    vapid = Vapid01()
    if VAPID_PRIVATE_PEM.exists():
        vapid.from_file(str(VAPID_PRIVATE_PEM))
    else:
        vapid.generate_keys()
        vapid.save_key(str(VAPID_PRIVATE_PEM))
    return {"public_key": vapid.public_key}


def _get_vapid() -> Vapid01:
    vapid = Vapid01()
    vapid.from_file(str(VAPID_PRIVATE_PEM))
    return vapid


def public_key_b64() -> str:
    """Chiave pubblica in formato base64url, quella da passare al browser (PushManager)."""
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    from py_vapid.utils import b64urlencode

    vapid = _get_vapid()
    raw = vapid.public_key.public_bytes(
        encoding=Encoding.X962,
        format=PublicFormat.UncompressedPoint,
    )
    return b64urlencode(raw)


def invia_notifica_a_tutti(titolo: str, corpo: str, dati_extra: dict | None = None):
    """Manda la stessa notifica a tutte le subscription registrate.
    Le subscription non più valide (410/404) vengono rimosse automaticamente."""
    payload = json.dumps({"title": titolo, "body": corpo, "data": dati_extra or {}})

    for sub in storage.lista_subscriptions():
        subscription_info = {
            "endpoint": sub["endpoint"],
            "keys": {"p256dh": sub["p256dh"], "auth": sub["auth"]},
        }
        try:
            webpush(
                subscription_info=subscription_info,
                data=payload,
                vapid_private_key=str(VAPID_PRIVATE_PEM),
                vapid_claims={"sub": config.get_vapid_contact_email()},
            )
        except WebPushException as e:
            status = getattr(e.response, "status_code", None)
            if status in (404, 410):
                storage.elimina_subscription(sub["endpoint"])
            else:
                print(f"[push] errore invio a {sub['endpoint'][:50]}...: {e}")
