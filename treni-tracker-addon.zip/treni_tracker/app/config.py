"""
Lettura delle opzioni dell'add-on.

Il Supervisor di Home Assistant scrive le opzioni che l'utente imposta
dalla scheda "Configurazione" dell'add-on (definite in config.yaml,
sezione "options"/"schema") nel file /data/options.json dentro il
container. Questo modulo le legge con dei default sensati, così
l'add-on funziona anche se l'utente non tocca nulla.
"""

import json
from pathlib import Path

OPTIONS_PATH = Path("/data/options.json")

_DEFAULTS = {
    "vapid_contact_email": "mailto:admin@example.com",
    "intervallo_polling_secondi": 75,
    "soglia_variazione_ritardo": 2,
}


def _load_options() -> dict:
    if not OPTIONS_PATH.exists():
        return {}
    try:
        with open(OPTIONS_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


_options = _load_options()


def get_vapid_contact_email() -> str:
    email = _options.get("vapid_contact_email", _DEFAULTS["vapid_contact_email"])
    return email if email.startswith("mailto:") else f"mailto:{email}"


def get_intervallo_polling_secondi() -> int:
    return int(_options.get("intervallo_polling_secondi", _DEFAULTS["intervallo_polling_secondi"]))


def get_soglia_variazione_ritardo() -> int:
    return int(_options.get("soglia_variazione_ritardo", _DEFAULTS["soglia_variazione_ritardo"]))
