import asyncio
import logging
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from . import storage, viaggiatreno, push, scheduler

logging.basicConfig(level=logging.INFO)

APP_DIR = Path(__file__).parent
app = FastAPI(title="Treni Tracker")

app.mount("/static", StaticFiles(directory=str(APP_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(APP_DIR / "templates"))


@app.on_event("startup")
async def startup():
    storage.init_db()
    push.init_vapid_keys()
    asyncio.create_task(scheduler.loop_scheduler())


# ---------- Pagine ----------

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    treni = storage.lista_treni_attivi()
    return templates.TemplateResponse(
        "index.html", {"request": request, "treni": treni}
    )


@app.get("/manifest.json")
async def manifest():
    return FileResponse(str(APP_DIR / "static" / "manifest.json"), media_type="application/manifest+json")


@app.get("/sw.js")
async def service_worker():
    return FileResponse(str(APP_DIR / "static" / "sw.js"), media_type="application/javascript")


# ---------- API: ricerca treno ----------

@app.get("/api/cerca-treno/{numero_treno}")
async def cerca_treno(numero_treno: str):
    try:
        candidati = await viaggiatreno.cerca_numero_treno(numero_treno)
    except viaggiatreno.TrainNotFoundError:
        raise HTTPException(status_code=404, detail="Nessun treno trovato con questo numero per oggi")

    return {"candidati": candidati}


class AggiungiTrenoBody(BaseModel):
    numero_treno: str
    stazione_partenza_cod: str
    stazione_partenza_nome: str
    timestamp_ms: int


@app.post("/api/treni")
async def aggiungi_treno(body: AggiungiTrenoBody):
    try:
        stato = await viaggiatreno.andamento_treno(
            body.stazione_partenza_cod, body.numero_treno, body.timestamp_ms
        )
    except viaggiatreno.TrainNoDataError as e:
        raise HTTPException(status_code=422, detail=str(e))

    data_corsa = datetime.fromtimestamp(body.timestamp_ms / 1000).strftime("%Y-%m-%d")

    treno_id = storage.aggiungi_treno(
        numero_treno=body.numero_treno,
        stazione_partenza_cod=body.stazione_partenza_cod,
        stazione_partenza_nome=body.stazione_partenza_nome,
        stazione_destinazione_nome=stato["stazione_destinazione"] or "",
        timestamp_ms=body.timestamp_ms,
        data_corsa=data_corsa,
    )
    return {"id": treno_id, "stato_iniziale": stato}


@app.get("/api/treni")
async def lista_treni():
    return {"treni": storage.lista_treni_attivi()}


@app.get("/api/treni/{treno_id}/stato")
async def stato_treno(treno_id: int):
    treni = storage.lista_treni_attivi()
    treno = next((t for t in treni if t["id"] == treno_id), None)
    if not treno:
        raise HTTPException(status_code=404, detail="Treno non trovato o non più monitorato")

    try:
        stato = await viaggiatreno.andamento_treno(
            treno["stazione_partenza_cod"], treno["numero_treno"], treno["timestamp_ms"]
        )
    except viaggiatreno.TrainNoDataError as e:
        raise HTTPException(status_code=422, detail=str(e))

    return stato


@app.delete("/api/treni/{treno_id}")
async def rimuovi_treno(treno_id: int):
    storage.elimina_treno(treno_id)
    return {"ok": True}


# ---------- API: push subscriptions ----------

@app.get("/api/push/public-key")
async def push_public_key():
    return {"public_key": push.public_key_b64()}


class SubscriptionBody(BaseModel):
    endpoint: str
    keys: dict


@app.post("/api/push/subscribe")
async def push_subscribe(body: SubscriptionBody):
    storage.salva_subscription(body.endpoint, body.keys["p256dh"], body.keys["auth"])
    return {"ok": True}


@app.post("/api/push/unsubscribe")
async def push_unsubscribe(body: dict):
    storage.elimina_subscription(body["endpoint"])
    return {"ok": True}


@app.post("/api/push/test")
async def push_test():
    push.invia_notifica_a_tutti("Test notifica", "Se vedi questo, le notifiche funzionano.")
    return {"ok": True}


@app.get("/api/health")
async def health():
    """Usato dal Supervisor di HA per i controlli di salute dell'add-on."""
    return {"status": "ok"}
