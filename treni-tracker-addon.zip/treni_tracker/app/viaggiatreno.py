"""
Client per le API non ufficiali di ViaggiaTreno (Trenitalia/RFI).

Queste API non sono documentate ufficialmente e possono cambiare o
interrompersi senza preavviso. Coprono treni Trenitalia (Regionale,
IC, AV) e, dove la rete è gestita da RFI, anche buona parte dei treni
di operatori regionali (es. TPER/FER in Emilia-Romagna, Trenord sulla
rete RFI). Italo e le tratte Trenord su rete non-RFI non sono coperte:
non esiste un'API pubblica nota per questi casi.
"""

import time
import httpx
from datetime import datetime
from typing import Optional

BASE_URL = "http://www.viaggiatreno.it/infomobilita/resteasy/viaggiatreno"

TIPO_FERMATA = {
    "P": "partenza",
    "A": "arrivo",
    "F": "transito",
}


class TrainNotFoundError(Exception):
    """Il numero treno non corrisponde a nessuna corsa nota."""


class TrainAmbiguousError(Exception):
    """Il numero treno corrisponde a più corse: serve specificare quale."""

    def __init__(self, candidates: list[dict]):
        self.candidates = candidates
        super().__init__(f"Numero treno ambiguo: {len(candidates)} corse trovate")


class TrainNoDataError(Exception):
    """Il treno esiste ma i dati di corsa non sono disponibili (cancellato/204)."""


def _midnight_timestamp_ms(data: Optional[str] = None) -> int:
    """Timestamp in ms della mezzanotte del giorno indicato (o oggi)."""
    if data:
        dt = datetime.strptime(data, "%Y-%m-%d")
    else:
        dt = datetime.now()
    midnight = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    return int(midnight.timestamp() * 1000)


async def cerca_numero_treno(numero_treno: str) -> list[dict]:
    """
    Cerca un numero treno e ritorna tutte le corse che lo usano oggi.
    """
    url = f"{BASE_URL}/cercaNumeroTrenoTrenoAutocomplete/{numero_treno}"
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(url)

    if resp.status_code != 200 or not resp.text.strip():
        raise TrainNotFoundError(f"Nessuna corsa trovata per il treno {numero_treno}")

    risultati = []
    for riga in resp.text.strip().splitlines():
        try:
            label, payload = riga.split("|")
            num, cod_stazione, ts = payload.split("-")
            nome_stazione = label.split(" - ", 1)[1]
            risultati.append(
                {
                    "numero": num,
                    "stazione_partenza_nome": nome_stazione,
                    "stazione_partenza_cod": cod_stazione,
                    "timestamp_ms": int(ts),
                }
            )
        except (ValueError, IndexError):
            continue

    if not risultati:
        raise TrainNotFoundError(f"Nessuna corsa trovata per il treno {numero_treno}")

    return risultati


async def andamento_treno(
    cod_stazione_partenza: str, numero_treno: str, timestamp_ms: int
) -> dict:
    """
    Stato di avanzamento di una corsa specifica: fermate, ritardo,
    posizione attuale, eventuale soppressione.
    """
    url = f"{BASE_URL}/andamentoTreno/{cod_stazione_partenza}/{numero_treno}/{timestamp_ms}"
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(url)

    if resp.status_code == 204:
        raise TrainNoDataError(
            f"Dati non disponibili per il treno {numero_treno} "
            f"(probabilmente cancellato o riprogrammato)"
        )
    if resp.status_code != 200:
        raise TrainNoDataError(
            f"Errore API ViaggiaTreno (status {resp.status_code}) per il treno {numero_treno}"
        )

    data = resp.json()
    return _normalizza_andamento(data)


def _normalizza_andamento(data: dict) -> dict:
    """Estrae solo i campi che servono dal blob enorme di ViaggiaTreno."""
    fermate = []
    for f in data.get("fermate", []):
        fermate.append(
            {
                "stazione": f.get("stazione"),
                "tipo": TIPO_FERMATA.get(f.get("tipoFermata"), f.get("tipoFermata")),
                "arrivo_previsto": f.get("arrivo_teorico"),
                "arrivo_effettivo": f.get("arrivoReale"),
                "partenza_prevista": f.get("partenza_teorica"),
                "partenza_effettiva": f.get("partenzaReale"),
                "ritardo": f.get("ritardo"),
                "binario_previsto": (f.get("binarioProgrammatoPartenzaDescrizione")
                                      or f.get("binarioProgrammatoArrivoDescrizione")),
                "binario_effettivo": (f.get("binarioEffettivoPartenzaDescrizione")
                                       or f.get("binarioEffettivoArrivoDescrizione")),
                "passata": bool(f.get("arrivoReale") or f.get("partenzaReale")),
            }
        )

    return {
        "numero": data.get("numeroTreno"),
        "stazione_partenza": data.get("origine"),
        "stazione_destinazione": data.get("destinazione"),
        "ritardo_minuti": data.get("ritardo", 0),
        "soppresso": bool(data.get("provvedimento") in (1, 2)),
        "in_stazione_partenza": data.get("nonPartito", False),
        "ultima_stazione_rilevata": data.get("stazioneUltimoRilevamento"),
        "orario_ultimo_rilevamento": data.get("oraUltimoRilevamento"),
        "fermate": fermate,
        "aggiornato_il": int(time.time()),
    }
