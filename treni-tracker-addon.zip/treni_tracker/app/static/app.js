// ============================================================
// Treni Tracker — logica client
// ============================================================

const REFRESH_INTERVAL_MS = 30000;

// ---------- Orologio in alto ----------

function tickClock() {
  const el = document.getElementById("clock");
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}
setInterval(tickClock, 1000);
tickClock();

// ---------- Service worker + push ----------

let swRegistration = null;

async function initServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  swRegistration = await navigator.serviceWorker.register("/sw.js");

  if (!("PushManager" in window)) return;

  const existingSub = await swRegistration.pushManager.getSubscription();
  const banner = document.getElementById("notif-banner");

  if (!existingSub && Notification.permission !== "denied") {
    banner.classList.remove("hidden");
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map((c) => c.charCodeAt(0)));
}

async function enablePushNotifications() {
  const permission = await Notification.requestPermission();
  if (permission !== "granted") {
    alert("Senza il permesso non posso inviarti notifiche.");
    return;
  }

  const { public_key } = await fetch("/api/push/public-key").then((r) => r.json());

  const subscription = await swRegistration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(public_key),
  });

  await fetch("/api/push/subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(subscription.toJSON()),
  });

  document.getElementById("notif-banner").classList.add("hidden");
}

document.getElementById("btn-enable-notif").addEventListener("click", enablePushNotifications);

// ---------- Ricerca e aggiunta treno ----------

const form = document.getElementById("add-train-form");
const inputNumero = document.getElementById("input-numero-treno");
const candidatesBox = document.getElementById("candidates");
const formError = document.getElementById("form-error");
const btnCerca = document.getElementById("btn-cerca");

function showError(msg) {
  formError.textContent = msg;
  formError.style.display = "block";
}

function clearError() {
  formError.style.display = "none";
  formError.textContent = "";
}

function renderCandidates(candidati) {
  candidatesBox.innerHTML = "";
  candidatesBox.style.display = "block";

  candidati.forEach((c) => {
    const div = document.createElement("div");
    div.className = "candidate";
    div.innerHTML = `<span>Treno ${c.numero}</span><span class="dest">da ${c.stazione_partenza_nome}</span>`;
    div.addEventListener("click", () => confermaTreno(c));
    candidatesBox.appendChild(div);
  });
}

async function confermaTreno(candidato) {
  btnCerca.disabled = true;
  clearError();

  try {
    const res = await fetch("/api/treni", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        numero_treno: candidato.numero,
        stazione_partenza_cod: candidato.stazione_partenza_cod,
        stazione_partenza_nome: candidato.stazione_partenza_nome,
        timestamp_ms: candidato.timestamp_ms,
      }),
    });

    if (!res.ok) {
      const err = await res.json();
      showError(err.detail || "Errore durante l'aggiunta del treno.");
      return;
    }

    candidatesBox.style.display = "none";
    candidatesBox.innerHTML = "";
    inputNumero.value = "";
    await refreshBoard();
  } catch (e) {
    showError("Errore di rete. Riprova.");
  } finally {
    btnCerca.disabled = false;
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearError();
  candidatesBox.style.display = "none";
  candidatesBox.innerHTML = "";

  const numero = inputNumero.value.trim();
  if (!numero) return;

  btnCerca.disabled = true;
  btnCerca.textContent = "Cerco…";

  try {
    const res = await fetch(`/api/cerca-treno/${encodeURIComponent(numero)}`);
    if (!res.ok) {
      const err = await res.json();
      showError(err.detail || "Treno non trovato.");
      return;
    }

    const data = await res.json();

    if (data.candidati.length === 1) {
      await confermaTreno(data.candidati[0]);
    } else {
      renderCandidates(data.candidati);
    }
  } catch (e) {
    showError("Errore di rete. Riprova.");
  } finally {
    btnCerca.disabled = false;
    btnCerca.textContent = "Cerca";
  }
});

// ---------- Board: refresh stato treni monitorati ----------

const board = document.getElementById("board");

function formatDelay(ritardo) {
  if (ritardo === null || ritardo === undefined) return { text: "—", cls: "" };
  if (ritardo > 0) return { text: `+${ritardo} min`, cls: "late" };
  if (ritardo < 0) return { text: `${ritardo} min`, cls: "early" };
  return { text: "in orario", cls: "ontime" };
}

async function refreshBoard() {
  const res = await fetch("/api/treni");
  if (!res.ok) return;
  const { treni } = await res.json();

  if (treni.length === 0) {
    board.innerHTML = '<div class="board-empty">Nessun treno monitorato.<br>Aggiungine uno qui sopra.</div>';
    return;
  }

  // Ricostruzione semplice: per una bacheca di poche righe non serve un diffing sofisticato
  const rows = await Promise.all(treni.map(renderTrainRow));
  board.innerHTML = "";
  rows.forEach((row) => board.appendChild(row));
}

async function renderTrainRow(treno) {
  const row = document.createElement("div");
  row.className = "train-row";
  row.dataset.id = treno.id;

  let stato = null;
  try {
    const res = await fetch(`/api/treni/${treno.id}/stato`);
    if (res.ok) stato = await res.json();
  } catch (e) {
    // ignoro, mostro comunque la riga con dati base
  }

  const delayInfo = stato ? formatDelay(stato.ritardo_minuti) : { text: "—", cls: "" };
  row.dataset.status = delayInfo.cls === "late" ? "late" : delayInfo.cls === "ontime" ? "ontime" : "";

  const stazioneAttuale = stato?.ultima_stazione_rilevata
    ? `Ultimo rilevamento: ${stato.ultima_stazione_rilevata}`
    : "In attesa di aggiornamento…";

  row.innerHTML = `
    <div class="train-row-top">
      <span class="train-number">${treno.numero_treno}</span>
      <span class="train-delay ${delayInfo.cls}">${delayInfo.text}</span>
    </div>
    <div class="train-route">
      ${treno.stazione_partenza_nome}<span class="arrow">→</span>${treno.stazione_destinazione_nome || "?"}
    </div>
    <div class="train-current-station">${stazioneAttuale}</div>
    <div class="train-actions">
      <button data-action="remove" data-id="${treno.id}">Rimuovi</button>
    </div>
  `;

  row.querySelector('[data-action="remove"]').addEventListener("click", async () => {
    await fetch(`/api/treni/${treno.id}`, { method: "DELETE" });
    await refreshBoard();
  });

  return row;
}

// Collega i bottoni "rimuovi" già presenti nel rendering server-side iniziale
document.querySelectorAll('[data-action="remove"]').forEach((btn) => {
  btn.addEventListener("click", async () => {
    await fetch(`/api/treni/${btn.dataset.id}`, { method: "DELETE" });
    await refreshBoard();
  });
});

// ---------- Avvio ----------

initServiceWorker();
refreshBoard();
setInterval(refreshBoard, REFRESH_INTERVAL_MS);
