"""
Storage SQLite.

Negli add-on di Home Assistant, /data è la cartella persistente
gestita dal Supervisor: sopravvive a riavvii e aggiornamenti
dell'add-on stesso (a differenza del resto del filesystem del
container, che viene ricreato da zero a ogni aggiornamento).
"""

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path("/data/traintracker.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS treni_monitorati (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero_treno TEXT NOT NULL,
    stazione_partenza_cod TEXT NOT NULL,
    stazione_partenza_nome TEXT NOT NULL,
    stazione_destinazione_nome TEXT,
    timestamp_ms INTEGER NOT NULL,
    data_corsa TEXT NOT NULL,
    attivo INTEGER NOT NULL DEFAULT 1,
    ultimo_ritardo INTEGER,
    ultima_stazione_notificata TEXT,
    ultimo_stato_json TEXT,
    creato_il TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    endpoint TEXT NOT NULL UNIQUE,
    p256dh TEXT NOT NULL,
    auth TEXT NOT NULL,
    creato_il TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def aggiungi_treno(
    numero_treno: str,
    stazione_partenza_cod: str,
    stazione_partenza_nome: str,
    stazione_destinazione_nome: str,
    timestamp_ms: int,
    data_corsa: str,
) -> int:
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO treni_monitorati
               (numero_treno, stazione_partenza_cod, stazione_partenza_nome,
                stazione_destinazione_nome, timestamp_ms, data_corsa)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (numero_treno, stazione_partenza_cod, stazione_partenza_nome,
             stazione_destinazione_nome, timestamp_ms, data_corsa),
        )
        return cur.lastrowid


def lista_treni_attivi() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM treni_monitorati WHERE attivo = 1 ORDER BY creato_il DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def lista_treni_tutti() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM treni_monitorati ORDER BY creato_il DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def rimuovi_treno(treno_id: int):
    with get_conn() as conn:
        conn.execute("UPDATE treni_monitorati SET attivo = 0 WHERE id = ?", (treno_id,))


def elimina_treno(treno_id: int):
    with get_conn() as conn:
        conn.execute("DELETE FROM treni_monitorati WHERE id = ?", (treno_id,))


def aggiorna_stato_treno(treno_id: int, ritardo: int, ultima_stazione: str, stato: dict):
    with get_conn() as conn:
        conn.execute(
            """UPDATE treni_monitorati
               SET ultimo_ritardo = ?, ultima_stazione_notificata = ?, ultimo_stato_json = ?
               WHERE id = ?""",
            (ritardo, ultima_stazione, json.dumps(stato), treno_id),
        )


def salva_subscription(endpoint: str, p256dh: str, auth: str):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO push_subscriptions (endpoint, p256dh, auth)
               VALUES (?, ?, ?)
               ON CONFLICT(endpoint) DO UPDATE SET p256dh = ?, auth = ?""",
            (endpoint, p256dh, auth, p256dh, auth),
        )


def elimina_subscription(endpoint: str):
    with get_conn() as conn:
        conn.execute("DELETE FROM push_subscriptions WHERE endpoint = ?", (endpoint,))


def lista_subscriptions() -> list[dict]:
    with get_conn() as conn:
        rows = conn.execute("SELECT * FROM push_subscriptions").fetchall()
        return [dict(r) for r in rows]
